#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from math import pow, atan2, sqrt
from gazebo_msgs.msg import ModelStates
from tf.transformations import euler_from_quaternion
from pid import PID
from prm import path

class TurtleBotController:

    def __init__(self):
        # Initialize the ROS node
        rospy.init_node('turtlebot_controller', anonymous=True)

        # Set up the velocity publisher
        self.velocity_pub = rospy.Publisher('/cmd_vel_mux/input/navi', Twist, queue_size=10)

        # Set up the pose subscriber
        self.pose_sub = rospy.Subscriber("/gazebo/model_states", ModelStates, self.update_pose)

        self.current_pose = Pose()
        self.rate = rospy.Rate(10)

    def update_pose(self, data):
        """Callback function to update the robot's pose based on Gazebo model states."""
        for i, name in enumerate(data.name):
            if name == 'mobile_base':
                self.current_pose.x = round(data.pose[i].position.x, 4)
                self.current_pose.y = round(data.pose[i].position.y, 4)
                
                orientation = data.pose[i].orientation
                _, _, self.current_pose.theta = euler_from_quaternion([orientation.x, orientation.y, orientation.z, orientation.w])
                break

    def get_distance(self, pose_a, pose_b):
        """Calculate the Euclidean distance between two poses."""
        return sqrt(pow((pose_b.x - pose_a.x), 2) + pow((pose_b.y - pose_a.y), 2))

    def linear_velocity(self, current_pose, target_pose, k=1.5):
        """Calculate linear velocity towards the target."""
        return k * self.get_distance(current_pose, target_pose)

    def steering_angle(self, current_pose, target_pose):
        """Calculate the angle towards the target."""
        return atan2(target_pose.y - current_pose.y, target_pose.x - current_pose.x)

    def angular_velocity(self, current_pose, target_pose, k=4.0):
        """Calculate angular velocity required to turn towards the target."""
        return k * (self.steering_angle(current_pose, target_pose) - current_pose.theta)

    def move_to_goal(self, goal_pose):
        """Move the robot towards a specified goal."""
        vel_msg = Twist()
        while not rospy.is_shutdown():
            pid_controller = PID()
            current_state = self.current_pose
            current_theta = current_state.theta

            distance = self.get_distance(current_state, goal_pose)
            linear_speed = pid_controller.compute_pid(distance)
            angular_speed = self.angular_velocity(current_state, goal_pose)

            vel_msg.linear.x = linear_speed
            vel_msg.angular.z = angular_speed

            self.velocity_pub.publish(vel_msg)

            if distance < 0.05:
                break

    def follow_path(self, waypoints):
        """Navigate through a series of waypoints."""
        for waypoint in waypoints:
            target_pose = Pose()
            target_pose.x = waypoint[0]
            target_pose.y = waypoint[1]
            self.move_to_goal(target_pose)

if __name__ == '__main__':
    try:
        reversed_path = path[::-1]
        controller = TurtleBotController()
        controller.follow_path(reversed_path)
        
    except rospy.ROSInterruptException:
        pass


