#!/usr/bin/env python

import sys
import math
import numpy as np
from scipy.spatial import KDTree
import os
from pid import PID  # Assuming this is a custom PID module
from geometry_msgs.msg import Twist, Point
import rospy

class Node:
    def __init__(self, x, y, cost, parent_index):
        self.x = x
        self.y = y
        self.cost = cost
        self.parent_index = parent_index

def changeToWorldCoords(r, c):
    y = 12.84753 - (c * 0.05188378405)
    x = 6.72835 - (r * 0.05324720745)
    return x, y

def changeToPixelCoords(x, y):
    c = round((12.84753 - y) / 0.05188378405)
    r = round((6.72835 - x) / 0.05324720745)
    return r, c

def prm(sx, sy, gx, gy, ox, oy, robot_radius):
    NN = KDTree(np.vstack((ox, oy)).T)
    randomx, randomy = random_points(sx, sy, gx, gy, robot_radius, ox, oy, NN)
    road_map = generateMap(randomx, randomy, robot_radius, NN)
    px, py = dijkstra_planning(sx, sy, gx, gy, road_map, randomx, randomy)
    return px, py

def is_collision(sx, sy, gx, gy, rr, NN):
    val = math.hypot(gx - sx, gy - sy)
    if val >= 30.0:
        return True
    n = int(val / rr)
    for i in range(n):
        dist, indexes = NN.query([sx, sy])
        if dist <= rr:
            return True
        sx = sx + rr * math.cos(math.atan2(gy - sy, gx - sx))
        sy = sy + rr * math.sin(math.atan2(gy - sy, gx - sx))
    dist, indexes = NN.query([gx, gy])
    if dist <= rr:
        return True
    return False

def generateMap(randomx, randomy, rr, NN):
    gmap = []
    n = len(randomx)
    sampleNN = KDTree(np.vstack((randomx, randomy)).T)
    for r, rx, ry in zip(range(n), randomx, randomy):
        dists, indexes = sampleNN.query([rx, ry], k=n)
        edge_id = []
        for i in range(1, len(indexes)):
            nx = randomx[indexes[i]]
            ny = randomy[indexes[i]]
            if not is_collision(rx, ry, nx, ny, rr, NN):
                edge_id.append(indexes[i])
            if len(edge_id) >= 10:
                break
        gmap.append(edge_id)
    return gmap

def dijkstra_planning(start_x, start_y, goal_x, goal_y, road_map, random_x, random_y):
    start_node = Node(start_x, start_y, 0.0, -1)
    goal_node = Node(goal_x, goal_y, 0.0, -1)
    open_set, closed_set = dict(), dict()
    open_set[len(road_map) - 2] = start_node
    path_found = True
    
    while True:
        if not open_set:
            print("Path not found")
            path_found = False
            break
        
        current_id = min(open_set, key=lambda o: open_set[o].cost)
        current = open_set[current_id]
        
        if current_id == (len(road_map) - 1):
            print("Goal reached!")
            goal_node.parent_index = current.parent_index
            goal_node.cost = current.cost
            break
        
        del open_set[current_id]
        closed_set[current_id] = current
        
        for neighbor_id in road_map[current_id]:
            neighbor_x = random_x[neighbor_id]
            neighbor_y = random_y[neighbor_id]
            dx = neighbor_x - current.x
            dy = neighbor_y - current.y
            distance = math.hypot(dx, dy)
            neighbor = Node(neighbor_x, neighbor_y, current.cost + distance, current_id)
            
            if neighbor_id in closed_set:
                continue
            
            if neighbor_id in open_set:
                if open_set[neighbor_id].cost > neighbor.cost:
                    open_set[neighbor_id].cost = neighbor.cost
                    open_set[neighbor_id].parent_index = current_id
            else:
                open_set[neighbor_id] = neighbor
    
    if not path_found:
        return [], []
    
    path_x, path_y = [goal_node.x], [goal_node.y]
    parent_index = goal_node.parent_index
    
    while parent_index != -1:
        node = closed_set[parent_index]
        path_x.append(node.x)
        path_y.append(node.y)
        parent_index = node.parent_index
    
    return path_x, path_y

def random_points(start_x, start_y, goal_x, goal_y, radius, obstacles_x, obstacles_y, NN):
    random_x = []
    random_y = []
    max_x = max(obstacles_x)
    max_y = max(obstacles_y)
    min_x = min(obstacles_x)
    min_y = min(obstacles_y)
    
    while len(random_x) <= 500:
        x = np.random.uniform(min_x, max_x)
        y = np.random.uniform(min_y, max_y)
        dis, _ = NN.query([x, y])
        if dis >= radius:
            random_x.append(x)
            random_y.append(y)
    
    random_x.extend([start_x, goal_x])
    random_y.extend([start_y, goal_y])
    
    return random_x, random_y


def changeToFinalCoords(finalpath):
    for i in range(finalpath.shape[0]):
        finalpath[i][0], finalpath[i][1] = changeToWorldCoords(round(finalpath[i][0]), round(finalpath[i][1]))
    return finalpath

def main():
    print(__file__ + " start.")
    pid = PID()  # Assuming this initializes PID for some control purpose
    state = pid.get_state()  # Assuming this retrieves the state
    sx = state.pose.position.x
    sy = state.pose.position.y
    gx = float(input('x value:'))
    gy = float(input('y value:'))
    sx, sy = changeToPixelCoords(sx, sy)
    gx, gy = changeToPixelCoords(gx, gy)
    print('initial px coords:', sx, sy)
    print('Goal px coords:', gx, gy)
    robot_radius = 5.0  # [m]
    imgArr = []
    with open(os.path.join(sys.path[0], "mapArray.txt")) as textFile:
        for line in textFile:
            lines = line.split(',')
            imgArr.append(lines)
    imgArr = np.array(imgArr).astype(int)
    ox = []
    oy = []
    for i in range(imgArr.shape[0]):
        for j in range(imgArr.shape[1]):
            if imgArr[i][j] == 1:
                ox.append(i)
                oy.append(j)
    px, py = prm(sx, sy, gx, gy, ox, oy, robot_radius)
    assert px, 'Path not found'
    finalpath = np.column_stack((px, py))
    finalpath = changeToFinalCoords(finalpath)
    print(finalpath)
    return finalpath

path = main()
